# nodejs小说爬虫
>共三个爬虫，支持爬取书籍信息，章节内容，章节标题

>数据存储在mysql中，通过node的mysql模块

用到了superagent、cheerio、mysql、express、async模块，具体说明参考[此博客](http://www.cnblogs.com/tgxh/p/7124202.html)

主要用于自己的[移动书城](https://github.com/tgxhx/vue-reader)项目，结合express构建的[api](https://github.com/tgxhx/node-book-api)